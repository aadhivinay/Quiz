package com.example.splashscreen
import com.google.firebase.database.IgnoreExtraProperties

data class UserData(
    val username: String? = null,
    val password: String? = null
)
